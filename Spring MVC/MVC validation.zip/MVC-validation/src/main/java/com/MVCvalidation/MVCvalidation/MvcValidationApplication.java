package com.MVCvalidation.MVCvalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcValidationApplication.class, args);
	}

}
