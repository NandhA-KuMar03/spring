package com.MVCvalidation.MVCvalidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
